import React from 'react';
import PropTypes from 'prop-types';
import './Button.scss';

function Button(props) {
    const { className, isDisabled, isLoading, children, type } = props;
    const classes = `button ${className ? className : ''} ${type ? `button--${type}` : ''} ${isDisabled ? 'disabled' : ''} ${isLoading ? 'loading' : ''}`
    return (
        <button {...props} className={classes.trim()}>
            {children}
        </button>
    );
}

Button.propTypes = {
    className: PropTypes.string,
    isDisabled: PropTypes.bool,
    isLoading: PropTypes.bool,
    children: PropTypes.node,
    type: PropTypes.string
}

export default Button;