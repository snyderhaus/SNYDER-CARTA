import React from 'react';
import { shallow } from 'enzyme';

import Button from './Button';

describe('Button', () => {
    const mockClick = jest.fn();
    const component = shallow(<Button onClick={mockClick} />);

    it('renders correctly', () => {
        expect(component).toMatchSnapshot();
    });

    it('executes the onClick', () => {
        component.find('button').simulate('click');
        expect(mockClick).toHaveBeenCalled();
    });
});