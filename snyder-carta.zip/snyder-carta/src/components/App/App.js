import React from 'react';
import SearchBar from '../SearchBar/SearchBar';
import Listings from '../Listings/Listings';
import ContextProvider from '../../context/ContextProvider';
import './App.scss';

function App() {
  return (
    <ContextProvider>
      <div className="App">
        <SearchBar />
        <Listings />
      </div>
    </ContextProvider>
  );
}

export default App;
