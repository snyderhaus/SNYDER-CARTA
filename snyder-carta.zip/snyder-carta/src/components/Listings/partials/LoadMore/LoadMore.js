import React from 'react';
import './load-more.scss';
import Button from '../../../_generic/Button/Button';
import Loader from '../../../_generic/Loader/Loader';
import WithContext from '../../../../context/WithContext';
import PropTypes from 'prop-types';

function LoadMore({ context }) {
    const { listings, getListings, loadingMore, querySize } = context;

    const handleLoadMore = () => {
        if (loadingMore) {
            return;
        }

        getListings(querySize);
    }

    if (!listings || !listings.length || listings === 'loading') {
        return null;
    }

    if (querySize >= 60 && !loadingMore) {
        return (
                <p className="load-more load-more--complete">That's all, folks!</p>
        );
    }
    
    return (
        <Button className="load-more__submit" type="secondary" onClick={() => handleLoadMore()}>
            {loadingMore 
                ? <Loader />
                : 'Load more'
            }
        </Button>
    );
};

LoadMore.propTypes = {
    context: PropTypes.shape({
        listings: PropTypes.oneOfType([
            PropTypes.string,
            PropTypes.array,
        ]),
        getListings: PropTypes.func,
        loadingMore: PropTypes.bool.isRequired,
        querySize: PropTypes.number.isRequired
    }),
}

export default WithContext(LoadMore);