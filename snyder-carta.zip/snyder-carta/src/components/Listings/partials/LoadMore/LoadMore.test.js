import React from 'react';
import renderer from 'react-test-renderer';
import { mount } from 'enzyme';

import LoadMore from './LoadMore';

describe('LoadMore', () => {
    test('snapshot renders', () => {
        const component = renderer.create(<LoadMore />);
        let tree = component.toJSON();
        expect(tree).toMatchSnapshot();
    });
});