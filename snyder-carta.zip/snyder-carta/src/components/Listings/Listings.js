import React, { Fragment } from 'react';
import Loader from '../_generic/Loader/Loader';
import './Listings.scss';
import WithContext from '../../context/WithContext';
import LoadMore from './partials/LoadMore/LoadMore';
import PropTypes from 'prop-types';

function Listing({ data }) {
    const { name, location, categories } = data;
    const { icon } = categories[0];
    const { address, city, distance, lat, lng } = location;

    return (
        <li className="listings__item">
            <a className="listings__item__link" href={`https://www.google.com/maps/search/?api=1&query=${lat},${lng}&query=${name.split(' ').join('+')}`} rel="noopener noreferrer" target="_blank">
                <div className="listings__item__icon">
                    <img src={`${icon.prefix}32${icon.suffix}`} className="" alt="" />
                </div>
                <span className="listings__item__content">
                    <h4 className="listings__item__name">{name}</h4>
                    <small className="listings__item__location">{address}, {city}</small>
                </span>
                {distance && <p className="listings__item__distance">{`${(distance / 1000).toFixed(1)}km`}</p>}
                <i className="">
                    <svg width="10" height="18" xmlns="http://www.w3.org/2000/svg"><path d="M7.69 9L.22 16.47a.75.75 0 001.06 1.06l8-8a.75.75 0 000-1.06l-8-8A.75.75 0 00.22 1.53L7.69 9z" fill="#ddd" fillRule="nonzero"/></svg>
                </i>
            </a>
        </li>
    );
}

Listing.propTypes = {
    data: PropTypes.shape({
        name: PropTypes.string,
        location: PropTypes.shape({
            address: PropTypes.string,
            city: PropTypes.string,
            distance: PropTypes.number,
            lat: PropTypes.number,
            lng: PropTypes.number
        }),
        categories: PropTypes.array

    }),
}

function Listings({ context }) {
    const { listings } = context;

    function showListing() {
        if (listings === null) {
            return null;
        }
    
        if (listings === 'loading') {
            return <Loader />
        }
    
        if (listings === 'error') {
            return <li className="listings__item"><p>Can't get listings from location.</p></li>;
        }
        
        return listings.length && listings.map(({ venue }, index) => <Listing key={index} data={venue} />);
    }

    return (
        <Fragment>
            <ul className="listings">
                {showListing()}
            </ul>
            <LoadMore />
        </Fragment>
    );
}

LoadMore.propTypes = {
    context: PropTypes.shape({
        listings: PropTypes.oneOfType([
            PropTypes.string,
            PropTypes.array,
        ])
    }),
}

export default WithContext(Listings);