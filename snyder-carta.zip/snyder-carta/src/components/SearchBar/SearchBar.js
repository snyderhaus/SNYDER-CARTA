import React from 'react';
import './SearchBar.scss';
import FindMe from './partials/FindMe/FindMe';
import WithContext from '../../context/WithContext';
import _ from 'lodash';
import PropTypes from 'prop-types';

function SearchBar({ context }) {

    const handleSearch = _.debounce(e => context.searchForLocation(e), 1000);

    return (
        <div className="searchbar">
            <i className="searchbar__icon">
                <svg width="20" height="20" xmlns="http://www.w3.org/2000/svg"><path d="M19.054 18.046a.713.713 0 01-1.008 1.008l-3.42-3.42a.713.713 0 011.008-1.008l3.42 3.42zM8.29 15.842a7.552 7.552 0 110-15.104 7.552 7.552 0 010 15.104zm0-1.425a6.128 6.128 0 100-12.255 6.128 6.128 0 000 12.256zM4.775 7.72a.475.475 0 11-.95 0A3.895 3.895 0 017.72 3.825a.475.475 0 110 .95A2.945 2.945 0 004.775 7.72z" fill="#1A051D" fillRule="nonzero"/></svg>
            </i>
            <input 
                type="input" 
                className="searchbar__input" 
                placeholder="Enter a city or landmark..." 
                onKeyUp={({ target }) => handleSearch(target.value)} 
            />
            <FindMe />
        </div>
    );
}

SearchBar.propTypes = {
    context: PropTypes.shape({
        searchForLocation: PropTypes.func
    })
}

export default WithContext(SearchBar);