import React from 'react';
import './FindMe.scss';
import WithContext from '../../../../context/WithContext';

function FindMe({ context }) {
    const { getCurrentLocation } = context;
    return (
        <button className="find-me" onClick={() => getCurrentLocation()}>
            <i className="find-me__icon">
                <svg width="16" height="16" xmlns="http://www.w3.org/2000/svg"><path d="M.769 4.05L14.596.098a1.049 1.049 0 011.284 1.284L11.93 15.21c-.297.889-1.482.988-1.877.099L7.287 8.79.77 6.025c-.988-.494-.889-1.68 0-1.976z" fill="#6979F8" fillRule="nonzero"/></svg>
            </i>
        </button>
    );
}

export default WithContext(FindMe);