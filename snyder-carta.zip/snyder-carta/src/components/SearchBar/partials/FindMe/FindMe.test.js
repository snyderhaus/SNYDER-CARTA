import React from 'react';
import renderer from 'react-test-renderer';

import FindMe from './FindMe';

describe('FindMe', () => {
    test('snapshot renders', () => {
        const component = renderer.create(<FindMe />);
        expect(component.toJSON()).toMatchSnapshot();
    });
});