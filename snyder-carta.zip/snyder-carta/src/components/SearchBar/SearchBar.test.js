import React from 'react';
import { mount } from 'enzyme';

import SearchBar from './SearchBar';

describe('SearchBar', () => {
    const mockClick = jest.fn();
    const context = {
        searchForLocation: mockClick
    };
    const component = mount(<SearchBar context={context} />);

    it('renders correctly', () => {
        expect(component).toMatchSnapshot();
    });

    it('executes the keyup', () => {
        component.find('.searchbar__input').prop('onKeyUp')({ target: 'target' })
        component.find('.searchbar__input').simulate('keyUp', { key: '1' });
        expect(mockClick).toHaveBeenCalled();
    });
});