import React, { Component } from 'react';
import { Context, DEFAULT_STATE } from './store';
import CONSTANTS from '../CONSTANTS';
import _ from 'lodash';

class ContextProvider extends Component {
    state = DEFAULT_STATE;

    searchForLocation = searchQuery => {
        const url = `https://api.foursquare.com/v2/venues/explore?client_id=${CONSTANTS.CLIENT_ID}&client_secret=${CONSTANTS.CLIENT_SECRET}&v=20180323&near=${searchQuery}`;

        console.log(`getListings(): Attempting to fetch url from search query: ${url}`);
        fetch(url)
        .then(resp => resp.json())
        .then(data => {
            const listings = data.response.groups[0].items;
            debugger
            console.log('getListings(): Successfully received listings.');
            const sortedListings = _.orderBy(listings, ({ venue }) =>  venue.location.distance, ['asc']);
            localStorage.setItem('listings', JSON.stringify(listings));
            this.setState((state) => ({ 
                listings: sortedListings, 
                loadingMore: false,
                querySize: state.querySize + 10
            }));
        })
        .catch(err => { 
            this.setState({ loadingMore: false });
            console.log(`getListings(): There was an error processing the fetch request. ${err}`)
        })
    }

    getCurrentLocation = () => {
      if (!navigator.geolocation) {
        console.log('getUserLocation(): Geolocation is not supported by this browser');
        return false;
      }

      this.setState({
          listings: 'loading'
      });
  
      navigator.geolocation.getCurrentPosition(
        ({ coords }) => {
            const { latitude, longitude } = coords;
            
            console.log(`getUserLocation(): Users current location. lat: ${latitude} lng: ${longitude}`);
            this.setState({
                currentLocation: {
                    latitude,
                    longitude
                },
                querySize: 10
            });
            this.getListings();
        }, err => {
            console.log(`getUserLocation(): There was an error retreiving location. ${JSON.stringify(err)}\nAttempting to use storedLocation...`)

            const storedCurrentLocation = localStorage.getItem('currentLocation');

            if (!storedCurrentLocation) {
                console.log('getUserLocation(): No stored location received.');
                this.setState({ currentLocation: {} });
                this.setState({
                    listings: 'error'
                });
                return false;
            }

            const { latitude, longitude } = JSON.parse(storedCurrentLocation);
            console.log('getUserLocation(): Successfully retrieved stored location.');
            
            this.setState({ 
                currentLocation: {
                    latitude,
                    longitude
                }
            });
        }
      );
    }
  
    getListings = () => {
        let storedCurrentLocation = localStorage.getItem('currentLocation');
        
        if (storedCurrentLocation) {
            storedCurrentLocation = JSON.parse(storedCurrentLocation);
        }

        const { currentLocation } = this.state;
  
        if (_.isEqual(currentLocation, storedCurrentLocation)) {
          const storedListings = localStorage.getItem('listings');
  
          if (storedListings) {
            this.setState({ listings: JSON.parse(storedListings) });
            console.log("getListings(): User location hasn't changed, using stored data.");
          }
          return;
        }
  
        console.log('getListings(): User location changed, fetching new listings.');
        localStorage.setItem('location', JSON.stringify(currentLocation));
  
        const { latitude, longitude } = currentLocation;
        const { searchQuery, querySize } = this.state;
        const url = `https://api.foursquare.com/v2/venues/explore?client_id=${CONSTANTS.CLIENT_ID}&client_secret=${CONSTANTS.CLIENT_SECRET}&v=20180323&ll=${latitude},${longitude}&query=${searchQuery}&limit=${querySize}`;

        this.setState({ loadingMore: true });

        console.log(`getListings(): Attempting to fetch url: ${url}`);
        fetch(url)
        .then(resp => resp.json())
        .then(data => {
            const listings = data.response.groups[0].items;
            
            console.log('getListings(): Successfully received listings.');
                
            const sortedListings = _.orderBy(listings, ({ venue }) =>  venue.location.distance, ['asc']);
            localStorage.setItem('listings', JSON.stringify(listings));
            this.setState((state) => ({ 
                listings: sortedListings, 
                loadingMore: false,
                querySize: state.querySize + 10
            }));
        })
        .catch(err => { 
            this.setState({ loadingMore: false });
            console.log(`getListings(): There was an error processing the fetch request. ${err}`)
        })
    }

    methods = {
        searchForLocation: this.searchForLocation,
        getCurrentLocation: this.getCurrentLocation,
        getListings: this.getListings
    }

    render() {
        const { children } = this.props;

        return (
            <Context.Provider value={{
                ...this.state,
                ...this.methods
            }}>
                {children}
            </Context.Provider>
        );
    }
}

export default ContextProvider;