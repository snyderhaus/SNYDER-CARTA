import React from 'react';
import { Context } from './store';

const WithContext = Component => props => (
	<Context.Consumer>
		{state => <Component {...props} context={state} />}
	</Context.Consumer>
);

export default WithContext
