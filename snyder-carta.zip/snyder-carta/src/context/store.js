import React from 'react';

export const DEFAULT_STATE = {
    listings: null,
    currentLocation: null,
    searchQuery: 'coffee',
    querySize: 10,
    loadingMore: false
};

export const Context = React.createContext(DEFAULT_STATE);